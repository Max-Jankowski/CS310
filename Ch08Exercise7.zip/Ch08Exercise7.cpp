//Max Jankowski
//CS310 Week 7 Assignment
//Bellevue University
//10-10-24 Chapter 8 Exercise 7

#include <iostream>
#include <string>
#include <iomanip>
using namespace std;

int main() {
    
    string candidate[5];  //Stores the names of the candidates.
    int votes[5];         //Array to store amount of votes each candidate receives.   
    int totalVotes = 0;   
    int winnerIs = 0;  //Will store the winner with the most votes
    
    
    //For loop that will ask for and store candidate name and votes
    for (int index = 0; index < 5; index ++) {
        cout << "Enter the last name of the candidate:  " <<index + 1 << ":";
        cin >> candidate[index]; //Stores name input of candidate. 
        
        cout << "Enter the amount of votes " << candidate[index] << " received. ";
        cin >> votes[index];  //Input for the votes array 
        
        totalVotes += votes[index]; //Added entered votes to the totalVotes variable 
        
        if (votes[index] > votes[winnerIs]) { //Checks to see if current input has more votes then prev. inputs
            winnerIs = index; //Updates winnerIs if candidate has more votes then prior inputs
            
        }
    }
            //Outputting the first row of final display
    cout << "\nCandidate \t\tVotes Received \t\t%of votes total votes" << endl;
    
    //For loop to go through candidates to diplay there names and votes
    for (int index = 0; index < 5; index++){
        //calculating total votes, declaring and initalizing percentage variable
        double percentage = (double)votes[index] / totalVotes * 100;
        
        //Output of last names, vote count and percentage of overall vote
        cout << candidate[index] << "\t\t\t" << votes[index] <<
        "\t\t\t" << fixed << setprecision(2) << percentage << "% \n" << endl;        
    }
    
    cout << "Total votes \t\t" << totalVotes << endl; //prints out last line of chart with total votes cast
    cout << "This winner of the election is " << candidate[winnerIs] << "." << endl;
    
    return 0;
}