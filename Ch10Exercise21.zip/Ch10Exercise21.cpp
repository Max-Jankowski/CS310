//Max Jankowski
//CS310 Week 8 Assignment

/*Listed below I used to better understand the function structure, I did not use the switch function
https://www.w3resource.com/cpp-exercises/oop/cpp-oop-exercise-5.php#google_vignette
https://www.tutorjoes.in/cpp_programming_tutorial/bank_in_cpp_program
https://cs.middlesexcc.edu/~schatz/csc134/handouts/accounts.constr.html
https://cplusplus.com/forum/general/207659/
Had some trouble with static initialization, and other parts of the code,so I used these resources for
references */

#include <iostream>
#include <string>

using namespace std;

//defining a class as chapter 10 pg 654 describes
class bankAccount {
// creating defined members of account class that can be used even outside of class
//Using a constructor as used on pgs 674 and on to help clean up and simplify
//the Main by initalizing objects in class
public:
    bankAccount(string name, string type, double rate, double initBalance) {
        accountNo = nextNumber++;
        accountName = name;
        accountType = type;
        balance = initBalance;
        interestRate = rate;
    }

    //User function to output account information
    void displayAccount() const {
        cout << "Account Number: " << accountNo << endl;
        cout << "Name On Account: " << accountName << endl;
        cout << "Type of Account: " << accountType << endl;
        cout << "Balance On Account: $" << balance << endl;
        cout << "Interest Rate: " << interestRate << "%" << endl;
    }

    //Function to allow money to be added outside of standard interest payment
    void depositToAccount(double amount) {
        if (amount > 0) {
            balance += amount;
            cout << "$ " << amount << " was added to the account, the new balance is: " << balance << endl;
        } else {
            cout << "Your deposit value is invalid" << endl;
        }
    }

    //function to decrease balance to simulate withdraw
    void withdrawFromAccount(double amount) {
        if (amount > 0 && amount <= balance) {
            balance -= amount;
            cout << "$ " << amount << " was withdrawn from the account, the new balance is $: " << balance << endl;
        } else {
            cout << "Insufficient funds or invalid input" << endl;
        }
    }

    //Function to calculate both calculate how much money the interest gather and add to balance
    void addInterestToAccount() {
        double interestPayment = balance * interestRate/100;
        balance += interestPayment; //adds to initBalance
        cout << "$" << interestPayment << " was added to the account, the new balance is: $" << balance << endl;
    }

private: //declaring variables that are only used directly within the class
    int accountNo;
    string accountName;
    string accountType;
    double interestRate;
    double balance;

    static int nextNumber;  // Static member to auto-assign account numbers
};

// initialize member to start counting accounts from
int bankAccount::nextNumber = 5550;

//Prototyping display of all accounts function, learned the hard way that it should be after defining class and variables
//was having a hard time debugging this one. Used above resources to help. 
void outputAccounts(bankAccount clients[], int size);

int main() {
    //declaring an array of 10 account components as specified.
    //stores object details that where set by constructor on line 22
    bankAccount clients[10] = {
        bankAccount("Max Jankowski", "Savings", 1.2, 8532.32),
        bankAccount("Jessica Monson", "Savings", 0.95, 10285.15),
        bankAccount("Maggie Jankowska", "Checking", 0.525, 1285.15),
        bankAccount("Anthony Hittle", "Checking", 0.45, 7852.36),
        bankAccount("John Wolfe", "Savings", 1.2, 8852),
        bankAccount("Luke Skywalker", "Checking", 0.35, 958.56),
        bankAccount("Leia Organa", "Savings", 1.6, 17535.23),
        bankAccount("Han Solo", "Checking", 0.45, -235.15),
        bankAccount("Rand al'Thor", "Savings", 1.2, 1585.32),
        bankAccount("Gandalf deGrey", "Savings", 1.5, 135523.15),
    };

    // First output of accounts
    outputAccounts(clients, 10);  // Correct function call
    
    cout << "\n Account Transations: " << endl;

    // Perform some operations on accounts added new lines to make it more readable. This is used to demo how accounts are influenced and 
    //check if the functions are working properly
    clients[0].depositToAccount(215);
    clients[1].withdrawFromAccount(75);
    clients[2].withdrawFromAccount(1253.32);
    clients[3].addInterestToAccount();
    clients[4].depositToAccount(178.25);
    clients[5].addInterestToAccount();
    clients[6].withdrawFromAccount(980.35);
    clients[7].withdrawFromAccount(178.25);
    clients[8].addInterestToAccount();
    clients[9].addInterestToAccount();

    cout << "\n New Account status: "<< endl;
    // Output accounts again after changes
    outputAccounts(clients, 10);  // Correct function call

    return 0;
}

// function that was prototyped to display account information from array.
void outputAccounts(bankAccount clients[], int size) {
    for (int i = 0; i < size; ++i) {
        cout << "\nAccount " << (i + 1) << " details:\n";
        clients[i].displayAccount();  // call to display ind. account info 
    }
}
